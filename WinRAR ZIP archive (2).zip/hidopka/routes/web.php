<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/create-product/{id}", [App\Http\Controllers\CreateProductController::class, 'index'])->name('create-product');
Route::get("/{id}", [App\Http\Controllers\PageController::class, 'page'])->name('page');
Route::get("/admin/{id}", [App\Http\Controllers\AdminController::class, 'index'])->name('admin');
Route::get("/create-directory/{id}", [App\Http\Controllers\CreateDirectoryController::class, 'index'])->name('create-directory');
Route::get("/remove/{id}", [App\Http\Controllers\PageController::class, 'delete'])->name('remove');
Route::get("/update/{id}", [App\Http\Controllers\PageController::class, 'update_index'])->name('update');
Route::get("/create-alias/{id}", [App\Http\Controllers\AliasController::class, 'index'])->name('create-alias');


Route::post('/create-product', [App\Http\Controllers\CreateProductController::class, 'add_product'])->name('pcreate-product');
Route::post('/create-directory', [App\Http\Controllers\CreateDirectoryController::class, 'add_directory'])->name('pcreate-directory');
Route::post("/update-directory", [App\Http\Controllers\CreateDirectoryController::class, 'update_dir'])->name('update_dir');
Route::post("/update-product", [App\Http\Controllers\CreateProductController::class, 'update_page'])->name('update_page');
Route::post('/create-alias', [App\Http\Controllers\AliasController::class, 'add_alias'])->name('pcreate-alias');
Route::post("/update-alias", [App\Http\Controllers\AliasController::class, 'update_alias'])->name('update_alias');
