@extends('app')

@section('content')
    <div class="background1">
        <div class="header1">
            <h3>a new product</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="{{route("pcreate-alias")}}" method="post" enctype="multipart/form-data">
                    <input required hidden type="text" name="parent" value="{{$parent}}">
                    @csrf
                    <p>id  <input required type="text" name="id" maxlength=”255” value="" class="inputarea"></p>
                    <p>title  <input type="text" name="title" maxlength=”255” value="" class="inputarea"></p>
                    <p>description  <input  type="text" name="description" maxlength=”1500” value="" class="inputarea"></p>
                    <select name="alias_to">
                        @foreach(DB::table("pages")->where("is_container", false)->where("alias_to", null)->get() as $page)
                        <option value="{{$page->id}}">{{$page->title}}</option>
                        @endforeach
                    </select>
                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
