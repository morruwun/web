@extends('app')

@section('content')
    <div class="background1">
        <div class="header1">
            <h3>a new product</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="{{route("update_page")}}" method="post" enctype="multipart/form-data">
                    @csrf
                    <input required hidden type="text" name="parent" value="{{$page->parent}}">
                    <input required hidden type="text" name="id" maxlength=”255” value="{{$page->id}}" class="inputarea">
                    <p>title  <input required type="text" name="title" maxlength=”255” value="{{$page->title}}" class="inputarea"></p>
                    <p>description  <input required type="text" name="description" maxlength=”1500” value="{{$page->description}}" class="inputarea"></p>
                    <p>price  <input required type="text" name="price" value="{{$page->price}}" class="inputarea"></p>
                    <p>amount in stock  <input required type="text" name="in_stock" value="{{$page->in_stock}}" class="inputarea"></p>
                    <p>photo   <input type="file" name="picture" accept="image/*"></p>
                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
