@extends('app')

@section('content')
    <div class="background1">
        <div class="container">
            <div class="header1">
                <h3>{{ $page->title}}</h3>
            </div>
            <div class="productcont">
                <div class="product">
                    <img class="product" src={{asset('storage/images/'.$page->photo)}}>
                </div>
                <div class="productinfo">
                    <h4>description</h4>
                    <p>{{ $page->description }}</p>
                    <div class="priceinfo">
                        <p>${{ $page->price }}</p>
                        <p >{{ $page->in_stock }} in stock</p>
                    </div>
                </div>
            </div>
            <div class="button">
                <a href="#" class="button1">add to cart</a>
            </div>
        </div>
    </div>
@endsection
