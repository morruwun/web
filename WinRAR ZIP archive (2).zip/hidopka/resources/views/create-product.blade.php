@extends('app')

@section('content')
    <div class="background1">
        <div class="header1">
            <h3>a new product</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="{{route('pcreate-product')}}" method="post" enctype="multipart/form-data">
                    <input required hidden type="text" name="parent" value="{{$parent}}">
                    @csrf
                    <p>id  <input required type="text" name="id" maxlength=”255” value="" class="inputarea"></p>
                    <p>title  <input required type="text" name="title" maxlength=”255” value="" class="inputarea"></p>
                    <p>description  <input required type="text" name="description" maxlength=”1500” value="" class="inputarea"></p>
                    <p>price  <input required type="text" name="price" value="" class="inputarea"></p>
                    <p>amount in stock  <input required type="text" name="in_stock" value="" class="inputarea"></p>
                    <p>photo   <input required type="file" name="picture" accept="image/*"></p>
                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
