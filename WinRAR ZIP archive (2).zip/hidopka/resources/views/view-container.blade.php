@extends('app')

@section('content')
    <div class="background">
        <div class="container">
            <div class="header">
                <h3>catalog</h3>
            </div>
            <div class="info">
                @foreach($pages as $page)
                    @if(!$page->is_container)
                        <div class="item">
                            <img src={{asset('storage/images/'.$page->photo)}} class="image">
                            <a href="{{ route("page", ["id" => $page->id]) }}" class="dcinfo">{{ $page->title}}</a>
                            <p class="price">${{ $page->price }}</p>
                            <div class="button">
                                <a href = "#" class="button">add to cart</a>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>

@endsection
