@extends('app')

@section('content')
    <div class="background1">
        <div class="container1">
            <div class="root">
                @foreach($path as $page)
                <a href="{{ route("admin", ["id" => $page->id]) }}" class="root_text">{{ $page->title}}</a>
                    @endforeach
            </div>
            <div class="menu_cont2">
                <a href="{{route("create-directory", ["id" => end($path)->id])}}">add directory</a>
                <a href="{{route("create-product", ["id" => end($path)->id])}}">create product</a>
                <a href="{{route("create-alias", ["id" => end($path)->id])}}">create alias</a>
            </div>
            <div class="cont2">
                <table class="table">
                    <thead><tr>
                        <th>id</th>
                        <th>title</th>
                        <th>description</th>
                        <th>price</th>
                        <th>in_stock</th>
                        <th>created</th>
                        <th>updated</th>
                        <th>actions</th>
                    </tr></thead><tbody>
                    @foreach($pages as $page)
                    <tr>
                        <td>{{$page->id}}@if($page->alias_id) (alias)@endif</td>
                        @if($page->is_container)
                            <td><a href="{{ route("admin", ["id" => $page->id]) }}">{{ $page->title }}</a></td>
                        @else
                            <td><a href="{{ route("page", ["id" => $page->id]) }}">{{ $page->title}}</a></td>
                            @endif
                        <td>{{$page->description}}</td>
                        <td>{{$page->price}}</td>
                        <td>{{$page->in_stock}}</td>
                        <td>{{$page->created}}</td>
                        <td>{{$page->updated}}</td>
                        <td>
                            @if($page->alias_id)
                                <a href="{{route("remove", ["id" => $page->alias_id])}}">remove</a>
                                <a href="{{route("update", ["id" => $page->alias_id])}}">update</a></td>
                            @else
                                <a href="{{route("remove", ["id" => $page->id])}}">remove</a>
                                <a href="{{route("update", ["id" => $page->id])}}">update</a></td>
                            @endif

                    </tr>
                    @endforeach</tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
