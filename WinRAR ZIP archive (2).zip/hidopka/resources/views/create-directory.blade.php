@extends('app')

@section('content')
    <div class="background1">
        <div class="header1">
            <h3>a new directory</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="{{route ("pcreate-directory")}}" method="post">
                    @csrf
                    <input required hidden type="text" name="parent" value="{{$parent}}">
                    <p>id  <input required type="text" name="id" maxlength=”255” value="" class="inputarea"></p>
                    <p>title  <input required type="text" name="title" maxlength=”255” value="" class="inputarea"></p>

                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
