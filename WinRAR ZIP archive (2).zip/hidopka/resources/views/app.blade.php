<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>gollyaka</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('public/assets/css/main.css')}}">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic+Coding:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    <header><div class="menu_back">
        <div class="container">
            <div class="menu_cont">
                <div class="logo_cont">
                    <img src="{{asset('public/assets/img/logo.png')}}" alt="logopic" class="logopic">
                    <div class="text1">
                        <div class="title">gollyaka</span>
                            <p class="store">dreamcatcher store</p>
                        </div>
                    </div>
                </div>
                <ul class="menubar">
                    @foreach(\App\Models\Page::getCategories() as $category)
                        <li><a href="{{ route("page", ["id" => $category->id]) }}">{{ $category->title }}</a></li>
                    @endforeach
                </ul>
                <img src="{{asset('public/assets/img/cart.png')}}" alt="cartpic" class="cartpic">
                <img src="{{asset('public/assets/img/menu.png')}}" class="pull">
            </div>
        </div>
    </div></header>
    @yield('content')

<footer><div class="footer">
        <div class="container">
            <div class="footitem">
                <img src="{{asset('public/assets/img/1.png')}}" class="footimage">
                <img src="{{asset('public/assets/img/2.png')}}" class="footimage">
                <img src="{{asset('public/assets/img/3.png')}}" class="footimage">
                <img src="{{asset('public/assets/img/4.png')}}" class="footimage">
            </div>
        </div>
    </div></footer>

</body>
</html>
