<?php

namespace App\Http\Controllers;

use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AliasController extends Controller
{
    public static function index($id) {
        return view("create-alias", ["parent" => $id]);
    }

    public static function add_alias(Request $request) {
        DB::table('pages')->insert([
            "id"=> $request->input("id"),
            "title"=> $request->input("title"),
            "description"=> $request->input("description"),
            "alias_to"=> $request->input("alias_to"),
            "parent"=> $request->input("parent")

        ]);
        return redirect()->route('admin', ['id' => $request->input("parent")]);
    }

    public static function update_alias(Request $request) {
        $resp = DB::table("pages")->where("id", $request->input("id"))->first();
        if ($resp) {
            DB::table("pages")->where("id", $request->input("id"))->update([
                "title"=> $request->input("title"),
                "description"=> $request->input("description"),
                "alias_to"=> $request->input("alias_to"),
                "updated"=> now()
            ]);
            return redirect()->route('admin', ['id' => $request->input("parent")]);
        }
        return "404";
    }
}
