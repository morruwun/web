<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Path;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public static function index($id) {
        return view("admin", [
            "pages" => Page::createPagesArray(DB::table("pages")->where("parent", "=", $id)->where("id", "!=", "root")->get()),
            "path"=> Path::getPathTo($id)
        ]);
    }
}
