<?php

namespace App\Http\Controllers;

use App\Models\Path;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Page;

class PageController extends Controller{

    public static function page($id) {
        $req = DB::table('pages')->where("id", "=", $id)->first();
        if ($req->is_container) {
            return view("view-container", [
                "pages" => Page::createPagesArray(DB::table("pages")->where("parent", "=", $req->id)->get())
            ]);
        }
        return view("view-product", ["page" => $req]);
    }

    public static function delete($id) {
        $resp = DB::table("pages")->where("id", $id)->first();
        Path::recursive_delete($id);
        if ($resp)
            return redirect()->route("admin", ["id" => $resp->parent]);
        return "404";
    }

    public static function update_index($id) {
        $resp = DB::table("pages")->where("id", $id)->first();
        if ($resp)
            if ($resp->is_container)
                return view("update-directory", [ "page" => $resp]);
            else if ($resp->alias_to)
                return view("update-alias", [ "page" => $resp]);
            else if (!$resp->is_container)
                return view("update-product", [ "page" => $resp]);
        return "404";
    }
}
