<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use Illuminate\Support\Facades\DB;
class CreateProductController extends Controller {

    public static function index($id) {
        return view("create-product", ["parent" => $id]);
    }

    public static function add_product(Request $request) {
        DB::table('pages')->insert([
            "id"=> $request->input("id"),
            "title"=> $request->input("title"),
            "description"=> $request->input("description"),
            "price"=> $request->input("price"),
            "in_stock"=> $request->input("in_stock"),
            "photo"=> Image::saveImage($request->file('picture')),
            "parent"=> $request->input("parent")

        ]);
        return redirect()->route('admin', ['id' => $request->input("parent")]);
    }
    public static function update_page(Request $request) {
        $resp = DB::table("pages")->where("id", $request->input("id"))->first();
        if ($resp) {
            if ($request->hasFile("photo")) {
                $new_photo = Image::saveImage($request->input("photo"));
                Image::deleteImage($resp->photo);
            } else {
                $new_photo = $resp->photo;
            }
            DB::table("pages")->where("id", $request->input("id"))->update([
                "title"=> $request->input("title"),
                "description"=> $request->input("description"),
                "price"=> $request->input("price"),
                "in_stock"=> $request->input("in_stock"),
                "photo" => $new_photo,
                "updated"=> now()
            ]);
            return redirect()->route('admin', ['id' => $request->input("parent")]);
        }
        return "404";
    }
}
