<?php

namespace App\Models;

use ArrayObject;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Page extends Model
{
    public $id, $title, $description, $photo, $is_container, $price, $in_stock, $created, $updated;
    public $alias_id = null;

    public function __construct($page) {
        $this->id = $page->id;
        $this->title = $page->title;
        $this->description = $page->description;
        $this->photo = $page->photo;
        $this->is_container = $page->is_container;
        $this->price = $page->price;
        $this->in_stock = $page->in_stock;
        $this->created = $page->created;
        $this->updated = $page->updated;
    }

    public static function create($page): Page {
        if ($page->alias_to) {
            $result = self::create( DB::table("pages")->where("id", $page->alias_to)->first() );
            $result->alias_id = $page->id;
            if ($page->title) $result->title = $page->title;
            if ($page->description) $result->description = $page->description;
            return $result;
        }
        return new Page($page);
    }

    public static function createPagesArray($pages) {
        $res = new ArrayObject();
        foreach ($pages as $page)
            $res->append(self::create($page));
        return $res;
    }

    public static function getCategories() {
        return DB::table("pages")->where("is_container", "=", true)->where("id", "!=", "root")->get();
    }
}
