<?php

namespace App\Models;

use ArrayObject;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Path extends Model {
    public static function getPathTo($id) {
        $db_resp = DB::table("pages")->where("id", $id)->first();
        $result = new ArrayObject();
        if (!$db_resp)
            return $result;
        while ($db_resp->id != $db_resp->parent) {
            $result->append($db_resp);
            $db_resp = DB::table("pages")->where("id", $db_resp->parent)->first();
        }
        $result -> append(DB::table("pages")->where("id", "root")->first());
        return array_reverse($result->getArrayCopy());
    }

    public static function recursive_delete($start) {
        $resp = DB::table("pages")->where("id", $start)->first();
        if (!$resp)
            return;
        $pages = DB::table("pages")->where("parent", $start)->get();
        foreach ($pages as $page) {
            self::recursive_delete($page->id);
        }
        $pages = DB::table("pages")->where("alias_to", $start)->get();
        foreach ($pages as $page) {
            self::recursive_delete($page->id);
        }
        Image::deleteImage($resp->photo);
        DB::table("pages")->where("id", $start)->delete();
    }
}
