<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>gollyaka</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/main.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic+Coding:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    <header><div class="menu_back">
        <div class="container">
            <div class="menu_cont">
                <div class="logo_cont">
                    <img src="<?php echo e(asset('public/assets/img/logo.png')); ?>" alt="logopic" class="logopic">
                    <div class="text1">
                        <div class="title">gollyaka</span>
                            <p class="store">dreamcatcher store</p>
                        </div>
                    </div>
                </div>
                <ul class="menubar">
                    <?php $__currentLoopData = \App\Models\Page::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route("page", ["id" => $category->id])); ?>"><?php echo e($category->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <img src="<?php echo e(asset('public/assets/img/cart.png')); ?>" alt="cartpic" class="cartpic">
                <img src="<?php echo e(asset('public/assets/img/menu.png')); ?>" class="pull">
            </div>
        </div>
    </div></header>
    <?php echo $__env->yieldContent('content'); ?>

<footer><div class="footer">
        <div class="container">
            <div class="footitem">
                <img src="<?php echo e(asset('public/assets/img/1.png')); ?>" class="footimage">
                <img src="<?php echo e(asset('public/assets/img/2.png')); ?>" class="footimage">
                <img src="<?php echo e(asset('public/assets/img/3.png')); ?>" class="footimage">
                <img src="<?php echo e(asset('public/assets/img/4.png')); ?>" class="footimage">
            </div>
        </div>
    </div></footer>

</body>
</html>
<?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/app.blade.php ENDPATH**/ ?>