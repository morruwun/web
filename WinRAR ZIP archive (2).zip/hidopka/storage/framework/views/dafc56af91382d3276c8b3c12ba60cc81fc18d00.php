<?php $__env->startSection('content'); ?>
    <div class="background">
        <div class="container">
            <div class="header">
                <h3>catalog</h3>
            </div>
            <div class="info">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$page->is_container): ?>
                        <div class="item">
                            <img src=<?php echo e(asset('storage/images/'.$page->photo)); ?> class="image">
                            <a href="<?php echo e(route("page", ["id" => $page->id])); ?>" class="dcinfo"><?php echo e($page->title); ?></a>
                            <p class="price">$<?php echo e($page->price); ?></p>
                            <div class="button">
                                <a href = "#" class="button">add to cart</a>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/view-container.blade.php ENDPATH**/ ?>