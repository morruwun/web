<?php $__env->startSection('content'); ?>
    <div class="background1">
        <div class="header1">
            <h3>a new directory</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="<?php echo e(route ("pcreate-directory")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input required hidden type="text" name="parent" value="<?php echo e($parent); ?>">
                    <p>id  <input required type="text" name="id" maxlength=”255” value="" class="inputarea"></p>
                    <p>title  <input required type="text" name="title" maxlength=”255” value="" class="inputarea"></p>

                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/create-directory.blade.php ENDPATH**/ ?>