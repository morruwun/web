<?php $__env->startSection('content'); ?>
    <div class="background1">
        <div class="header1">
            <h3>a new product</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="<?php echo e(route("update_page")); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input required hidden type="text" name="parent" value="<?php echo e($page->parent); ?>">
                    <input required hidden type="text" name="id" maxlength=”255” value="<?php echo e($page->id); ?>" class="inputarea">
                    <p>title  <input required type="text" name="title" maxlength=”255” value="<?php echo e($page->title); ?>" class="inputarea"></p>
                    <p>description  <input required type="text" name="description" maxlength=”1500” value="<?php echo e($page->description); ?>" class="inputarea"></p>
                    <p>price  <input required type="text" name="price" value="<?php echo e($page->price); ?>" class="inputarea"></p>
                    <p>amount in stock  <input required type="text" name="in_stock" value="<?php echo e($page->in_stock); ?>" class="inputarea"></p>
                    <p>photo   <input type="file" name="picture" accept="image/*"></p>
                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/update-product.blade.php ENDPATH**/ ?>