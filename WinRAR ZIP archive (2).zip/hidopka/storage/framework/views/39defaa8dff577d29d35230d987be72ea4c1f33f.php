<?php $__env->startSection('content'); ?>
    <div class="background1">
        <div class="header1">
            <h3>a new product</h3>
        </div>
        <div class="formcont">
            <div class="myform">
                <form action="<?php echo e(route("update_alias")); ?>" method="post" enctype="multipart/form-data">
                    <input required hidden type="text" name="parent" value="<?php echo e($page->parent); ?>">
                    <input required hidden type="text" name="id" maxlength=”255” value="<?php echo e($page->id); ?>" class="inputarea">
                    <?php echo csrf_field(); ?>
                    <p>title  <input type="text" name="title" maxlength=”255” value="<?php echo e($page->title); ?>" class="inputarea"></p>
                    <p>description  <input  type="text" name="description" maxlength=”1500” value="<?php echo e($page->description); ?>" class="inputarea"></p>
                    <select name="alias_to" value="<?php echo e($page->alias_to); ?>">
                        <?php $__currentLoopData = DB::table("pages")->where("is_container", false)->where("alias_to", null)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($page->id); ?>"><?php echo e($page->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="finish">
                        <p><input type="submit" name="finish" value="finish"></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/update-alias.blade.php ENDPATH**/ ?>