<?php $__env->startSection('content'); ?>
    <div class="background1">
        <div class="container1">
            <div class="root">
                <?php $__currentLoopData = $path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route("admin", ["id" => $page->id])); ?>" class="root_text"><?php echo e($page->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="menu_cont2">
                <a href="<?php echo e(route("create-directory", ["id" => end($path)->id])); ?>">add directory</a>
                <a href="<?php echo e(route("create-product", ["id" => end($path)->id])); ?>">create product</a>
                <a href="<?php echo e(route("create-alias", ["id" => end($path)->id])); ?>">create alias</a>
            </div>
            <div class="cont2">
                <table class="table">
                    <thead><tr>
                        <th>id</th>
                        <th>title</th>
                        <th>description</th>
                        <th>price</th>
                        <th>in_stock</th>
                        <th>created</th>
                        <th>updated</th>
                        <th>actions</th>
                    </tr></thead><tbody>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($page->id); ?><?php if($page->alias_id): ?> (alias)<?php endif; ?></td>
                        <?php if($page->is_container): ?>
                            <td><a href="<?php echo e(route("admin", ["id" => $page->id])); ?>"><?php echo e($page->title); ?></a></td>
                        <?php else: ?>
                            <td><a href="<?php echo e(route("page", ["id" => $page->id])); ?>"><?php echo e($page->title); ?></a></td>
                            <?php endif; ?>
                        <td><?php echo e($page->description); ?></td>
                        <td><?php echo e($page->price); ?></td>
                        <td><?php echo e($page->in_stock); ?></td>
                        <td><?php echo e($page->created); ?></td>
                        <td><?php echo e($page->updated); ?></td>
                        <td>
                            <?php if($page->alias_id): ?>
                                <a href="<?php echo e(route("remove", ["id" => $page->alias_id])); ?>">remove</a>
                                <a href="<?php echo e(route("update", ["id" => $page->alias_id])); ?>">update</a></td>
                            <?php else: ?>
                                <a href="<?php echo e(route("remove", ["id" => $page->id])); ?>">remove</a>
                                <a href="<?php echo e(route("update", ["id" => $page->id])); ?>">update</a></td>
                            <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/admin.blade.php ENDPATH**/ ?>