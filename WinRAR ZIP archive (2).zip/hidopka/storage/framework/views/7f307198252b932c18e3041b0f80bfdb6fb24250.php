<?php $__env->startSection('content'); ?>
    <div class="background1">
        <div class="container">
            <div class="header1">
                <h3><?php echo e($page->title); ?></h3>
            </div>
            <div class="productcont">
                <div class="product">
                    <img class="product" src=<?php echo e(asset('storage/images/'.$page->photo)); ?>>
                </div>
                <div class="productinfo">
                    <h4>description</h4>
                    <p><?php echo e($page->description); ?></p>
                    <div class="priceinfo">
                        <p>$<?php echo e($page->price); ?></p>
                        <p ><?php echo e($page->in_stock); ?> in stock</p>
                    </div>
                </div>
            </div>
            <div class="button">
                <a href="#" class="button1">add to cart</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.0-0\apache2\htdocs\hidopka\resources\views/view-product.blade.php ENDPATH**/ ?>